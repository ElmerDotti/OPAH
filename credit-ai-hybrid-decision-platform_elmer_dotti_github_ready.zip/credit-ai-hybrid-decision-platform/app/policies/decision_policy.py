"""Política explícita de decisão, fallback e revisão humana."""

from __future__ import annotations

from dataclasses import dataclass

from app.core.settings import get_settings
from app.domain.schemas import CreditApplicationRequest, Decision, RetrievedEvidence, RiskScore


@dataclass(frozen=True)
class PolicyOutcome:
    decision: Decision
    fallback_reason: str | None
    trace: list[str]


class CreditDecisionPolicy:
    def decide(self, request: CreditApplicationRequest, risk: RiskScore, evidence: list[RetrievedEvidence]) -> PolicyOutcome:
        settings = get_settings()
        trace: list[str] = []

        if request.company.days_past_due_last_12m >= 90:
            trace.append("hard_rule: atraso >= 90 dias nos últimos 12 meses")
            return PolicyOutcome(Decision.DENY, None, trace)

        if request.company.debt_service_coverage_ratio < 0.8:
            trace.append("hard_rule: DSCR < 0,8 indica incapacidade de serviço da dívida")
            return PolicyOutcome(Decision.DENY, None, trace)

        if not request.documents:
            trace.append("fallback: documentos ausentes; decisão só com dados estruturados")
            if settings.risk_review_min_score <= risk.score <= settings.risk_review_max_score:
                return PolicyOutcome(Decision.REVIEW, "missing_contextual_documents", trace)

        if risk.score >= settings.risk_approval_min_score:
            trace.append(f"score_policy: score {risk.score} >= {settings.risk_approval_min_score}")
            return PolicyOutcome(Decision.APPROVE, None, trace)

        if settings.risk_review_min_score <= risk.score <= settings.risk_review_max_score:
            trace.append("score_policy: zona cinzenta exige revisão humana")
            low_evidence = evidence and max(e.score for e in evidence) < 0.05
            return PolicyOutcome(Decision.REVIEW, "gray_zone_or_low_evidence" if low_evidence else None, trace)

        trace.append(f"score_policy: score {risk.score} < {settings.risk_review_min_score}")
        return PolicyOutcome(Decision.DENY, None, trace)
