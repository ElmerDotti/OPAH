"""Serviço local de DLP para mascaramento de PII.

Em produção, este adaptador deve ser trocado pelo Google Cloud Sensitive Data Protection.
A interface permanece igual para evitar acoplamento entre privacidade e RAG.
"""

from __future__ import annotations

import re

CNPJ_RE = re.compile(r"\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b")
CPF_RE = re.compile(r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"\b(?:\+55\s?)?(?:\(?\d{2}\)?\s?)?9?\d{4}-?\d{4}\b")


class LocalDLPService:
    def deidentify(self, text: str) -> str:
        text = CNPJ_RE.sub("[CNPJ_REDACTED]", text)
        text = CPF_RE.sub("[CPF_REDACTED]", text)
        text = EMAIL_RE.sub("[EMAIL_REDACTED]", text)
        text = PHONE_RE.sub("[PHONE_REDACTED]", text)
        return text
