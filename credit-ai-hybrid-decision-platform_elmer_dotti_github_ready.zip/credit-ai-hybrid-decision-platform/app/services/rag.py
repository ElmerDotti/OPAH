"""RAG local com TF-IDF para grounding demonstrativo.

A implementação é deliberadamente simples para execução local. Na GCP, o mesmo contrato
é implementado por Vertex AI Embeddings + Vector Search + Gemini com system prompt restritivo.
"""

from __future__ import annotations

from dataclasses import dataclass

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.domain.schemas import DocumentEvidence, RetrievedEvidence, RiskScore
from app.services.dlp import LocalDLPService


@dataclass
class GroundedMemo:
    evidence: list[RetrievedEvidence]
    memo: str


class LocalRAGService:
    def __init__(self, dlp: LocalDLPService | None = None):
        self.dlp = dlp or LocalDLPService()

    def retrieve(self, query: str, documents: list[DocumentEvidence], top_k: int = 3) -> list[RetrievedEvidence]:
        if not documents:
            return []
        corpus = [self.dlp.deidentify(d.text) for d in documents]
        vectorizer = TfidfVectorizer(stop_words=None, ngram_range=(1, 2), max_features=3000)
        matrix = vectorizer.fit_transform(corpus + [query])
        sims = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
        ranked = sorted(enumerate(sims), key=lambda x: x[1], reverse=True)[:top_k]
        results = []
        for idx, score in ranked:
            doc = documents[idx]
            excerpt = corpus[idx][:420].replace("\n", " ")
            results.append(RetrievedEvidence(doc_id=doc.doc_id, source_type=doc.source_type, score=round(float(score), 4), excerpt=excerpt))
        return results

    def generate_memo(self, risk: RiskScore, evidence: list[RetrievedEvidence]) -> str:
        if not evidence:
            return (
                "Parecer contextual indisponível: nenhum documento elegível foi fornecido. "
                "A decisão deve se apoiar no score tabular e, se estiver em zona cinzenta, seguir para revisão humana."
            )
        citations = "; ".join([f"{e.doc_id}:{e.source_type}:sim={e.score}" for e in evidence])
        drivers = "; ".join([f"{r.feature} ({r.direction}, {r.contribution})" for r in risk.reason_codes[:3]])
        return (
            f"Parecer fundamentado: a aplicação recebeu rating {risk.rating}, score {risk.score} "
            f"e PD estimada de {risk.probability_of_default:.2%}. Os principais fatores quantitativos foram {drivers}. "
            f"As evidências textuais recuperadas foram {citations}. Caso haja divergência entre evidência documental e score, "
            "o fluxo recomenda revisão humana com trilha de auditoria completa."
        )
