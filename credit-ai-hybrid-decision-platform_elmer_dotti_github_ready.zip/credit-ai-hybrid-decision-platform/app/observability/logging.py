"""Logging estruturado com campos adequados para trilha de auditoria."""

import logging
import sys

from pythonjsonlogger import jsonlogger

from app.core.settings import get_settings


def configure_logging() -> None:
    settings = get_settings()
    logger = logging.getLogger()
    logger.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    formatter = jsonlogger.JsonFormatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s %(request_id)s %(decision)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(settings.log_level.upper())
