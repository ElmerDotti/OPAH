"""Métricas Prometheus simplificadas para operação da decisão de crédito."""

from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

DECISION_COUNTER = Counter(
    "credit_decisions_total",
    "Total de decisões de crédito por status.",
    ["decision", "fallback_reason"],
)
LATENCY = Histogram("credit_decision_latency_seconds", "Latência da decisão de crédito.")


def metrics_response() -> tuple[bytes, str]:
    return generate_latest(), CONTENT_TYPE_LATEST
