"""Configuração central da aplicação.

A solução foi desenhada para rodar localmente sem dependências pagas e para evoluir para GCP
substituindo adaptadores locais por Vertex AI, BigQuery, Feature Store, Document AI, DLP e Vector Search.
"""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "local"
    app_name: str = "credit-ai-hybrid-decision-platform"
    log_level: str = "INFO"
    rag_top_k: int = 3
    risk_review_min_score: int = 420
    risk_review_max_score: int = 680
    risk_approval_min_score: int = 681
    enable_fake_llm: bool = True

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    return Settings()
