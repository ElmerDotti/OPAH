"""Orquestrador da jornada de decisão.

Este componente materializa a arquitetura do relatório: dados estruturados → score/PD →
RAG contextual → política → auditoria. Ele é propositalmente fino para facilitar testes e
substituição de adaptadores locais por serviços gerenciados em nuvem.
"""

from __future__ import annotations

import time

from app.core.settings import get_settings
from app.domain.schemas import CreditApplicationRequest, CreditDecisionResponse
from app.models.risk_model import CreditRiskModel
from app.observability.metrics import DECISION_COUNTER, LATENCY
from app.policies.decision_policy import CreditDecisionPolicy
from app.services.rag import LocalRAGService


class DecisionOrchestrator:
    def __init__(self):
        self.settings = get_settings()
        self.risk_model = CreditRiskModel()
        self.rag = LocalRAGService()
        self.policy = CreditDecisionPolicy()

    def decide(self, request: CreditApplicationRequest) -> CreditDecisionResponse:
        start = time.perf_counter()
        risk = self.risk_model.predict(request.company)
        query = self._build_rag_query(request)
        evidence = self.rag.retrieve(query, request.documents, top_k=self.settings.rag_top_k)
        memo = self.rag.generate_memo(risk, evidence)
        policy = self.policy.decide(request, risk, evidence)
        elapsed = time.perf_counter() - start
        DECISION_COUNTER.labels(policy.decision.value, policy.fallback_reason or "none").inc()
        LATENCY.observe(elapsed)
        return CreditDecisionResponse(
            request_id=request.request_id,
            decision=policy.decision,
            fallback_reason=policy.fallback_reason,
            risk=risk,
            retrieved_evidence=evidence,
            grounded_memo=memo,
            policy_trace=policy.trace,
            audit={
                "model_family": "local_proxy_for_xgboost_calibrated_pd",
                "rag_backend": "local_tfidf_proxy_for_vertex_ai_vector_search_gemini",
                "latency_ms": round(elapsed * 1000, 2),
                "human_review_required": policy.decision.value == "REVIEW",
            },
        )

    @staticmethod
    def _build_rag_query(request: CreditApplicationRequest) -> str:
        c = request.company
        return (
            f"analisar risco de crédito PME setor {c.sector}, receita anual {c.annual_revenue_brl}, "
            f"valor solicitado {c.requested_amount_brl}, atrasos {c.days_past_due_last_12m}, DSCR {c.debt_service_coverage_ratio}"
        )
