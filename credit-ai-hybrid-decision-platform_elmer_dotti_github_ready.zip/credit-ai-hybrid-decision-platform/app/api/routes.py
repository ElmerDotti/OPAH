"""Rotas HTTP da plataforma."""

from fastapi import APIRouter, Response

from app.domain.schemas import CreditApplicationRequest, CreditDecisionResponse
from app.observability.metrics import metrics_response
from app.orchestration.decision_orchestrator import DecisionOrchestrator

router = APIRouter()
orchestrator = DecisionOrchestrator()


@router.get("/health", tags=["ops"])
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/v1/credit/decide", response_model=CreditDecisionResponse, tags=["credit"])
def decide_credit(request: CreditApplicationRequest) -> CreditDecisionResponse:
    return orchestrator.decide(request)


@router.get("/metrics", tags=["ops"])
def metrics() -> Response:
    body, content_type = metrics_response()
    return Response(content=body, media_type=content_type)
