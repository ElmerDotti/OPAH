"""Motor de risco tabular inspirado em práticas de scorecards e gradient boosting.

Em produção, este arquivo deve ser substituído por um artefato treinado e versionado no
Vertex AI Model Registry, por exemplo um XGBoost calibrado. Para o desafio, o módulo entrega
uma implementação determinística, testável e explicável, com a mesma interface esperada por
um endpoint de modelo real.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from app.domain.schemas import CompanyProfile, ReasonCode, RiskScore


def sigmoid(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(min(z, 35), -35)))


@dataclass(frozen=True)
class FeatureContribution:
    name: str
    value: float
    coefficient: float
    explanation: str

    @property
    def contribution(self) -> float:
        return self.value * self.coefficient


class CreditRiskModel:
    """Modelo proxy de PD para execução local e testes.

    A formulação é: PD = sigma(beta0 + soma_i beta_i x_i), onde PD é a probabilidade
    de inadimplência, sigma é a função logística, beta0 é o intercepto, beta_i são pesos
    calibráveis e x_i são variáveis normalizadas da empresa. Em produção, os pesos são
    substituídos por árvores de decisão do XGBoost calibradas por validação temporal.
    """

    def predict(self, company: CompanyProfile) -> RiskScore:
        revenue_m = company.annual_revenue_brl / 1_000_000
        leverage = company.current_debt_brl / max(company.annual_revenue_brl, 1.0)
        requested_to_revenue = company.requested_amount_brl / max(company.annual_revenue_brl, 1.0)
        cashflow_to_installment_proxy = company.avg_monthly_cashflow_brl / max(company.requested_amount_brl / 24, 1.0)

        features = [
            FeatureContribution("bureau_score", (600 - company.credit_bureau_score) / 200, 0.95, "Score bureau abaixo de 600 aumenta risco."),
            FeatureContribution("days_past_due_last_12m", company.days_past_due_last_12m / 30, 0.75, "Atrasos recentes indicam fragilidade de pagamento."),
            FeatureContribution("leverage", leverage, 1.40, "Maior dívida sobre receita reduz capacidade incremental."),
            FeatureContribution("requested_to_revenue", requested_to_revenue, 1.10, "Pedido elevado contra receita anual aumenta exposição."),
            FeatureContribution("dscr", 1.2 - company.debt_service_coverage_ratio, 1.25, "DSCR menor que 1,2 reduz margem de segurança."),
            FeatureContribution("cashflow_buffer", -min(cashflow_to_installment_proxy, 5) / 5, 0.55, "Fluxo de caixa recorrente amortiza risco de parcela."),
            FeatureContribution("firm_age", -min(company.years_in_business, 10) / 10, 0.35, "Maior histórico operacional reduz incerteza."),
            FeatureContribution("revenue_scale", -min(revenue_m, 20) / 20, 0.25, "Maior escala de receita tende a reduzir volatilidade."),
        ]
        logit = -1.25 + sum(f.contribution for f in features)
        pd = sigmoid(logit)
        score = int(round(1000 * (1 - pd)))
        rating = self._rating(score)
        reason_codes = self._reason_codes(features)
        return RiskScore(probability_of_default=round(pd, 4), score=score, rating=rating, reason_codes=reason_codes)

    @staticmethod
    def _rating(score: int) -> str:
        if score >= 820:
            return "A"
        if score >= 700:
            return "B"
        if score >= 560:
            return "C"
        if score >= 420:
            return "D"
        return "E"

    @staticmethod
    def _reason_codes(features: list[FeatureContribution]) -> list[ReasonCode]:
        ordered = sorted(features, key=lambda f: abs(f.contribution), reverse=True)[:5]
        return [
            ReasonCode(
                feature=f.name,
                contribution=round(f.contribution, 4),
                direction="risk_increase" if f.contribution > 0 else "risk_decrease",
                explanation=f.explanation,
            )
            for f in ordered
        ]
