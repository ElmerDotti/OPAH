"""Contratos de entrada e saída da API.

Os schemas separam dados estruturados de crédito, documentos textuais e metadados de
rastreamento. Essa separação segue a arquitetura híbrida: ML clássico para tabelas e RAG para texto.
"""

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class Decision(str, Enum):
    APPROVE = "APPROVE"
    DENY = "DENY"
    REVIEW = "REVIEW"
    OPERATIONAL_PENDING = "OPERATIONAL_PENDING"


class CompanyProfile(BaseModel):
    cnpj: str = Field(..., description="CNPJ da empresa, usado apenas para rastreio e mascarado em logs.")
    legal_name: str
    sector: str
    years_in_business: float = Field(..., ge=0)
    annual_revenue_brl: float = Field(..., ge=0)
    requested_amount_brl: float = Field(..., gt=0)
    avg_monthly_cashflow_brl: float
    current_debt_brl: float = Field(..., ge=0)
    days_past_due_last_12m: int = Field(..., ge=0)
    credit_bureau_score: int = Field(..., ge=0, le=1000)
    debt_service_coverage_ratio: float = Field(..., ge=0)


class DocumentEvidence(BaseModel):
    doc_id: str
    source_type: str = Field(..., examples=["contract", "email", "news", "financial_statement"])
    text: str


class CreditApplicationRequest(BaseModel):
    request_id: str
    company: CompanyProfile
    documents: list[DocumentEvidence] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("documents")
    @classmethod
    def limit_documents(cls, docs: list[DocumentEvidence]) -> list[DocumentEvidence]:
        if len(docs) > 20:
            raise ValueError("máximo de 20 documentos por solicitação no modo demonstrativo")
        return docs


class ReasonCode(BaseModel):
    feature: str
    contribution: float
    direction: str
    explanation: str


class RetrievedEvidence(BaseModel):
    doc_id: str
    source_type: str
    score: float
    excerpt: str


class RiskScore(BaseModel):
    probability_of_default: float
    score: int
    rating: str
    reason_codes: list[ReasonCode]


class CreditDecisionResponse(BaseModel):
    request_id: str
    decision: Decision
    fallback_reason: str | None = None
    risk: RiskScore
    retrieved_evidence: list[RetrievedEvidence]
    grounded_memo: str
    policy_trace: list[str]
    audit: dict[str, Any]
