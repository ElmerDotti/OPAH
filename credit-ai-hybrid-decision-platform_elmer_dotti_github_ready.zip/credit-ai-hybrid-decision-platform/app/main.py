"""Entrada FastAPI.

Executar localmente:
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"""

from fastapi import FastAPI

from app.api.routes import router
from app.core.settings import get_settings
from app.observability.logging import configure_logging

configure_logging()
settings = get_settings()

app = FastAPI(
    title="Credit AI Hybrid Decision Platform",
    description="API híbrida para decisão de crédito PME com score tabular, RAG, DLP, fallback, auditoria e governança.",
    version="1.0.0",
)
app.include_router(router)


@app.get("/")
def root() -> dict[str, str]:
    return {"service": settings.app_name, "docs": "/docs", "health": "/health"}
