#!/usr/bin/env bash
set -euo pipefail
curl -s -X POST "http://localhost:8000/v1/credit/decide" \
  -H "Content-Type: application/json" \
  -d @examples/requests/credit_application_approve.json | python -m json.tool
