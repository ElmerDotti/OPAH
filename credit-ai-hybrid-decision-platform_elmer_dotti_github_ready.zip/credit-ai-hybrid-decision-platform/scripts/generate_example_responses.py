"""Gera respostas JSON de exemplo a partir dos payloads versionados.

Uso:
    python scripts/generate_example_responses.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from app.domain.schemas import CreditApplicationRequest  # noqa: E402
from app.orchestration.decision_orchestrator import DecisionOrchestrator  # noqa: E402

REQUESTS = REPO / "examples" / "requests"
RESPONSES = REPO / "examples" / "responses"


def main() -> None:
    orchestrator = DecisionOrchestrator()
    RESPONSES.mkdir(parents=True, exist_ok=True)
    for request_path in sorted(REQUESTS.glob("*.json")):
        payload = json.loads(request_path.read_text(encoding="utf-8"))
        request = CreditApplicationRequest.model_validate(payload)
        response = orchestrator.decide(request).model_dump(mode="json")
        output_path = RESPONSES / f"{request_path.stem}_response.json"
        output_path.write_text(json.dumps(response, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"generated {output_path.relative_to(REPO)}")


if __name__ == "__main__":
    main()
