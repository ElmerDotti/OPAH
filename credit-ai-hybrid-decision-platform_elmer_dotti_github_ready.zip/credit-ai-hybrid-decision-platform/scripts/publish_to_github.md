# Como subir este projeto no GitHub

Este guia assume que você já criou um repositório vazio no GitHub, por exemplo `credit-ai-hybrid-decision-platform`.

```bash
cd credit-ai-hybrid-decision-platform
git init
git add .
git commit -m "feat: implement hybrid AI credit decision platform"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/credit-ai-hybrid-decision-platform.git
git push -u origin main
```

Caso prefira usar GitHub CLI:

```bash
cd credit-ai-hybrid-decision-platform
git init
git add .
git commit -m "feat: implement hybrid AI credit decision platform"
gh repo create credit-ai-hybrid-decision-platform --public --source=. --remote=origin --push
```

Antes de enviar, rode:

```bash
make setup
make test
make lint
```
