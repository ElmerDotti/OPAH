# Exemplos de respostas

Os arquivos desta pasta podem ser regenerados com:

```bash
make run
curl -s -X POST http://localhost:8000/v1/credit/decide \
  -H 'Content-Type: application/json' \
  -d @examples/requests/credit_application_approve.json | jq .
```

As respostas variam apenas se as políticas de threshold forem alteradas no `.env`.
