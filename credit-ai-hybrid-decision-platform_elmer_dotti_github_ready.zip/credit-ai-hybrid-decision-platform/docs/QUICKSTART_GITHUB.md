# Passo a passo direto para publicar no GitHub

Este guia foi escrito para submissão rápida do projeto ao recrutador. Ele assume que o repositório já foi descompactado localmente.

## 1. Entrar na pasta do projeto

```bash
cd credit-ai-hybrid-decision-platform
```

## 2. Validar a execução local antes do envio

```bash
cp .env.example .env
make setup
source .venv/bin/activate
make test
make lint
```

## 3. Rodar a API localmente

```bash
make run
```

A documentação interativa ficará disponível em:

```text
http://localhost:8000/docs
```

## 4. Testar um exemplo realista de entrada

Em outro terminal, execute:

```bash
curl -s -X POST http://localhost:8000/v1/credit/decide \
  -H 'Content-Type: application/json' \
  -d @examples/requests/credit_application_approve.json | python -m json.tool
```

## 5. Criar o repositório no GitHub

Crie no GitHub um repositório vazio chamado, por exemplo:

```text
credit-ai-hybrid-decision-platform
```

## 6. Fazer o primeiro commit e push

```bash
git init
git add .
git commit -m "feat: implement hybrid AI credit decision platform"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/credit-ai-hybrid-decision-platform.git
git push -u origin main
```

## 7. Conferir no GitHub

Após o push, confirme se os seguintes arquivos aparecem corretamente na página inicial do repositório:

| Arquivo ou pasta | O que o recrutador encontrará |
|---|---|
| `README.md` | Visão geral, execução local, Docker, testes e alinhamento com a solução. |
| `app/` | Código-fonte da API, modelo de risco, RAG, DLP, orquestração e políticas. |
| `docs/` | Arquitetura, deploy, governança, model card, referências e quickstart. |
| `examples/` | Payloads de entrada e respostas esperadas. |
| `infra/` | Docker, Cloud Build e blueprint Terraform. |
| `tests/` | Testes automatizados de API, DLP e motor de risco. |
