# Model Card — Credit Risk Proxy

## Objetivo

Estimar risco de crédito PME por meio de variáveis estruturadas e retornar probabilidade de default, score, rating e reason codes. O artefato local é um proxy explicável para demonstrar a arquitetura; em produção, deve ser substituído por XGBoost calibrado e monitorado.

## Entradas

| Variável | Descrição | Risco de uso |
|---|---|---|
| `credit_bureau_score` | Score externo de bureau | Pode refletir vieses históricos e deve ser monitorado. |
| `days_past_due_last_12m` | Atrasos recentes | Forte sinal de risco, mas requer qualidade temporal. |
| `debt_service_coverage_ratio` | Capacidade de serviço da dívida | Depende da confiabilidade contábil. |
| `current_debt_brl` e `annual_revenue_brl` | Alavancagem | Sensível a sazonalidade e subdeclaração. |

## Limitações

O MVP não deve ser utilizado para decisão real de crédito sem treinamento, validação estatística, aprovação de risco, auditoria legal e calibração com dados históricos. O objetivo é demonstrar arquitetura, contratos, governança e execução técnica.

## Monitoramento recomendado

Monitorar AUC/KS, Brier Score, calibration curve, drift populacional, estabilidade de features, taxa de aprovação, inadimplência observada por safra, disparidade por segmentos permitidos, latência, custo por decisão e taxa de revisão humana.
