# Referências técnicas e científicas

Este repositório materializa a solução descrita no relatório técnico e preserva as referências conceituais usadas para justificar as decisões de arquitetura. A implementação local não depende de serviços externos pagos, mas foi desenhada para evoluir diretamente para um ambiente de produção na GCP.

| Tema | Referência | Uso na solução |
|---|---|---|
| Gradient Boosting para dados tabulares | Chen e Guestrin, “XGBoost: A Scalable Tree Boosting System” | Fundamenta a recomendação de substituir o proxy local por XGBoost calibrado em produção. |
| Explicabilidade | Lundberg e Lee, “A Unified Approach to Interpreting Model Predictions” | Fundamenta reason codes e SHAP em produção. |
| Retrieval-Augmented Generation | Lewis et al., “Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks” | Fundamenta o uso de recuperação documental antes da geração do parecer. |
| Governança de IA | NIST AI Risk Management Framework | Fundamenta gestão de risco, governança, monitoramento e controles humanos. |
| RAG em Google Cloud | Google Cloud, arquitetura RAG com Vertex AI | Fundamenta a evolução de TF-IDF local para embeddings, Vector Search e Gemini. |
| Segurança de perímetro | Google Cloud, VPC Service Controls for Vertex AI | Fundamenta mitigação de exfiltração em ambientes regulados. |
| Privacidade | Google Cloud Sensitive Data Protection | Fundamenta DLP antes de logs, prompts e armazenamento contextual. |

## Links

[1]: https://arxiv.org/abs/1603.02754 "XGBoost: A Scalable Tree Boosting System"
[2]: https://arxiv.org/abs/1705.07874 "A Unified Approach to Interpreting Model Predictions"
[3]: https://arxiv.org/abs/2005.11401 "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks"
[4]: https://www.nist.gov/itl/ai-risk-management-framework "NIST AI Risk Management Framework"
[5]: https://cloud.google.com/architecture/rag-capable-gen-ai-app-using-vertex-ai "RAG-capable generative AI application using Vertex AI"
[6]: https://cloud.google.com/vertex-ai/docs/general/vpc-service-controls "VPC Service Controls with Vertex AI"
[7]: https://cloud.google.com/sensitive-data-protection/docs/deidentify-sensitive-data "De-identify sensitive data"
