# Deploy local, Docker e GCP

## Execução local

```bash
cp .env.example .env
make setup
source .venv/bin/activate
make run
```

Acesse `http://localhost:8000/docs` para testar a API interativa.

## Execução com Docker

```bash
make docker-build
make docker-run
```

## Exemplo de chamada

```bash
curl -s -X POST http://localhost:8000/v1/credit/decide \
  -H 'Content-Type: application/json' \
  -d @examples/requests/credit_application_approve.json | jq .
```

## Deploy GCP recomendado

O caminho de produção recomendado é Cloud Build para construir a imagem, Artifact Registry para armazená-la e Cloud Run para servir a API. Em ambientes regulados, recomenda-se complementar com Secret Manager, KMS/CMEK, VPC Service Controls, Cloud Armor, IAM mínimo, logs redigidos e monitoramento contínuo.

```bash
gcloud builds submit --config infra/cloudbuild/cloudbuild.yaml \
  --substitutions _REGION=us-central1,_REPOSITORY=credit-ai
```

O diretório `infra/terraform` contém o blueprint de infraestrutura como código para evolução corporativa controlada.
