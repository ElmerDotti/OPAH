# Governança, segurança e fallback

A solução foi desenhada para evitar que falhas técnicas ou baixa confiança se transformem automaticamente em negação de crédito. A política diferencia decisão de risco, pendência operacional e revisão humana.

| Situação | Ação | Justificativa |
|---|---|---|
| Score alto e sem hard rule negativa | Aprovação | Baixo risco estimado e decisão operacional eficiente. |
| Score baixo ou hard rule crítica | Negação | Exposição incompatível com política de crédito. |
| Zona cinzenta | Revisão humana | Reduz decisões frágeis quando há incerteza. |
| Documentos ausentes na zona cinzenta | Revisão humana | Contexto insuficiente para parecer robusto. |
| Falha técnica crítica | Pendência operacional | Falha sistêmica não deve prejudicar o cliente. |

## Controles recomendados

A produção deve incluir IAM mínimo, segregação de ambientes, logs redigidos, criptografia em repouso e trânsito, DLP antes de prompt, VPC Service Controls, revisão de decisões automatizadas, rastreabilidade por `request_id` e comitê de mudança para thresholds e modelos.
