# Arquitetura técnica

A plataforma implementa a arquitetura híbrida proposta no relatório técnico. O desenho separa responsabilidades entre dados estruturados, documentos não estruturados e governança operacional. O motor tabular calcula **PD**, **score**, **rating** e **reason codes**; o serviço RAG recupera evidências textuais e produz um parecer contextual; a política explícita decide aprovação, negação, revisão humana ou pendência operacional.

| Camada | Implementação local | Equivalente em produção GCP | Razão técnica |
|---|---|---|---|
| API | FastAPI | Cloud Run + API Gateway | Baixa latência, contrato HTTP simples e escalabilidade horizontal. |
| Risco tabular | `CreditRiskModel` proxy | Vertex AI Endpoint com XGBoost calibrado | Dados tabulares de crédito são melhor tratados por modelos supervisionados explicáveis. |
| Explicabilidade | Reason codes determinísticos | SHAP + Model Monitoring | Permite auditoria e comunicação objetiva com risco/negócio. |
| RAG | TF-IDF local | Vertex AI Embeddings + Vector Search + Gemini | Grounding textual para contratos, e-mails e notícias. |
| Privacidade | Regex DLP local | Sensitive Data Protection | Reduz exposição de PII em logs, prompts e evidências. |
| Política | `CreditDecisionPolicy` | Motor de regras versionado | Evita decisões frágeis e explicita thresholds e fallback. |
| Observabilidade | Prometheus local | Cloud Monitoring + Logging | Monitorar latência, custo, drift, fallback e decisões. |

## Fluxo ponta a ponta

1. A API recebe uma solicitação de crédito PME com dados estruturados e documentos.
2. O orquestrador calcula a probabilidade de default por meio do motor tabular.
3. O serviço de DLP mascara PII dos documentos antes da recuperação textual.
4. O RAG recupera evidências relevantes e gera parecer fundamentado.
5. A política de decisão aplica hard rules, thresholds e regras de zona cinzenta.
6. A resposta retorna decisão, score, PD, rating, reason codes, evidências, parecer e trilha de auditoria.

## Formulação do score

No MVP local, a probabilidade de inadimplência é calculada por uma função logística:

```text
PD = σ(β0 + Σ βᵢxᵢ)
```

Onde `PD` é a probabilidade de default, `σ` é a função logística, `β0` é o intercepto, `βᵢ` são pesos calibráveis e `xᵢ` são variáveis normalizadas. O score final é calculado por:

```text
score = round(1000 × (1 − PD))
```

Em produção, essa interface deve ser substituída por um XGBoost calibrado, mantendo o mesmo contrato de resposta para preservar API, testes e governança.
