# Terraform — blueprint de produção GCP

Este diretório contém um esqueleto seguro para evoluir o MVP local para produção. Em um ambiente real, os módulos devem criar Artifact Registry, Cloud Run, Pub/Sub, BigQuery, Vertex AI, IAM mínimo, VPC Service Controls, Cloud Logging, Secret Manager e KMS/CMEK.

O arquivo `main.tf` abaixo é intencionalmente minimalista para não criar recursos sem revisão. Ele documenta o contrato IaC esperado pelo recrutador e evita custos acidentais.
