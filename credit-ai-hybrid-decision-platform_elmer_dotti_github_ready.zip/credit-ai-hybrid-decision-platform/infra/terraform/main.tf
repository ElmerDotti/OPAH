terraform {
  required_version = ">= 1.5.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = ">= 5.0"
    }
  }
}

variable "project_id" { type = string }
variable "region" { default = "us-central1" }

provider "google" {
  project = var.project_id
  region  = var.region
}

# Produção recomendada:
# 1. google_artifact_registry_repository para imagens Docker.
# 2. google_cloud_run_v2_service com service account dedicada.
# 3. google_bigquery_dataset para features, auditoria e decisões.
# 4. IAM mínimo por serviço e Secret Manager para segredos.
# 5. Vertex AI Feature Store, Model Registry e endpoints privados.
# 6. VPC Service Controls e CMEK para redução de exfiltração.

output "deployment_note" {
  value = "Blueprint Terraform documentado. Completar módulos específicos conforme conta GCP e governança corporativa."
}
