# Segurança e privacidade

Este projeto é uma implementação demonstrativa para processo seletivo e não deve receber dados reais de clientes sem revisão formal de segurança, jurídico, risco e compliance.

## Recomendações para produção

A implantação produtiva deve utilizar segredos em Secret Manager, criptografia com KMS/CMEK, IAM mínimo por serviço, logs com redaction, DLP antes de prompts e armazenamento, VPC Service Controls, revisão humana em zona cinzenta e trilha auditável por `request_id`.

## Dados sensíveis

Os exemplos versionados são sintéticos e não representam clientes reais. Nunca envie CNPJ, CPF, e-mails, telefones ou documentos reais para ambientes não governados.

## Vulnerabilidades

Em caso de identificação de vulnerabilidade, registre uma issue privada no fluxo corporativo aplicável ou comunique o responsável pelo processo seletivo antes de qualquer divulgação pública.
