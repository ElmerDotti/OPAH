from app.domain.schemas import CompanyProfile
from app.models.risk_model import CreditRiskModel


def test_better_profile_has_higher_score_than_risky_profile():
    model = CreditRiskModel()
    good = CompanyProfile(
        cnpj="12.345.678/0001-90",
        legal_name="Boa PME",
        sector="serviços",
        years_in_business=10,
        annual_revenue_brl=10_000_000,
        requested_amount_brl=300_000,
        avg_monthly_cashflow_brl=500_000,
        current_debt_brl=300_000,
        days_past_due_last_12m=0,
        credit_bureau_score=850,
        debt_service_coverage_ratio=2.0,
    )
    bad = CompanyProfile(
        cnpj="98.765.432/0001-10",
        legal_name="Risco PME",
        sector="varejo",
        years_in_business=1,
        annual_revenue_brl=1_200_000,
        requested_amount_brl=900_000,
        avg_monthly_cashflow_brl=20_000,
        current_debt_brl=1_100_000,
        days_past_due_last_12m=75,
        credit_bureau_score=430,
        debt_service_coverage_ratio=0.7,
    )
    assert model.predict(good).score > model.predict(bad).score
