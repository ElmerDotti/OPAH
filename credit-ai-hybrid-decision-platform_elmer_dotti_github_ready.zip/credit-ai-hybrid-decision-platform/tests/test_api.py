from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_decision_endpoint():
    payload = {
        "request_id": "REQ-TEST-1",
        "company": {
            "cnpj": "12.345.678/0001-90",
            "legal_name": "Teste Ltda",
            "sector": "serviços",
            "years_in_business": 5,
            "annual_revenue_brl": 5000000,
            "requested_amount_brl": 300000,
            "avg_monthly_cashflow_brl": 250000,
            "current_debt_brl": 500000,
            "days_past_due_last_12m": 0,
            "credit_bureau_score": 760,
            "debt_service_coverage_ratio": 1.5
        },
        "documents": [{"doc_id": "d1", "source_type": "contract", "text": "contrato recorrente com pagamentos em dia"}],
        "metadata": {}
    }
    response = client.post("/v1/credit/decide", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["request_id"] == "REQ-TEST-1"
    assert body["risk"]["score"] >= 0
    assert body["decision"] in {"APPROVE", "DENY", "REVIEW", "OPERATIONAL_PENDING"}
