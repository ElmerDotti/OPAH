from app.services.dlp import LocalDLPService


def test_dlp_masks_common_pii():
    text = "CNPJ 12.345.678/0001-90, email pessoa@empresa.com.br e telefone +55 11 99999-0000"
    masked = LocalDLPService().deidentify(text)
    assert "[CNPJ_REDACTED]" in masked
    assert "[EMAIL_REDACTED]" in masked
    assert "[PHONE_REDACTED]" in masked
